import express from 'express'
import { z } from 'zod'
import { storage } from './storage.js'
import { insertPlayerSchema, insertGameSchema, insertTransactionSchema } from '../shared/schema.js'

const router = express.Router()

// Players routes
router.get('/api/players', (req, res) => {
  const players = storage.getAllPlayers()
  res.json(players)
})

router.get('/api/players/:id', (req, res) => {
  const player = storage.getPlayer(req.params.id)
  if (!player) {
    return res.status(404).json({ error: 'Joueur non trouvé' })
  }
  res.json(player)
})

router.post('/api/players', (req, res) => {
  try {
    const playerData = insertPlayerSchema.parse(req.body)
    
    // Vérifier si le nom d'utilisateur existe déjà
    const existingPlayer = storage.getPlayerByUsername(playerData.username)
    if (existingPlayer) {
      return res.status(400).json({ error: 'Ce nom d\'utilisateur existe déjà' })
    }
    
    const player = storage.createPlayer(playerData)
    res.status(201).json(player)
  } catch (error) {
    res.status(400).json({ error: 'Données invalides' })
  }
})

router.patch('/api/players/:id', (req, res) => {
  try {
    const updates = req.body
    const player = storage.updatePlayer(req.params.id, updates)
    if (!player) {
      return res.status(404).json({ error: 'Joueur non trouvé' })
    }
    res.json(player)
  } catch (error) {
    res.status(400).json({ error: 'Données invalides' })
  }
})

// Games routes
router.get('/api/games', (req, res) => {
  const games = storage.getAllGames()
  res.json(games)
})

router.get('/api/games/:id', (req, res) => {
  const game = storage.getGame(req.params.id)
  if (!game) {
    return res.status(404).json({ error: 'Partie non trouvée' })
  }
  res.json(game)
})

router.get('/api/players/:playerId/games', (req, res) => {
  const games = storage.getPlayerGames(req.params.playerId)
  res.json(games)
})

router.post('/api/games', (req, res) => {
  try {
    const gameData = insertGameSchema.parse(req.body)
    
    // Vérifier que les joueurs existent et ont assez de solde
    const player1 = storage.getPlayer(gameData.player1Id)
    const player2 = storage.getPlayer(gameData.player2Id)
    
    if (!player1 || !player2) {
      return res.status(400).json({ error: 'Un ou plusieurs joueurs non trouvés' })
    }
    
    if (player1.balance < gameData.betAmount || player2.balance < gameData.betAmount) {
      return res.status(400).json({ error: 'Solde insuffisant pour l\'un des joueurs' })
    }
    
    const game = storage.createGame(gameData)
    res.status(201).json(game)
  } catch (error) {
    res.status(400).json({ error: 'Données invalides' })
  }
})

router.patch('/api/games/:id', (req, res) => {
  try {
    const updates = req.body
    const game = storage.updateGame(req.params.id, updates)
    if (!game) {
      return res.status(404).json({ error: 'Partie non trouvée' })
    }
    res.json(game)
  } catch (error) {
    res.status(400).json({ error: 'Données invalides' })
  }
})

// Route spéciale pour terminer une partie et mettre à jour les soldes
router.post('/api/games/:id/complete', (req, res) => {
  try {
    const gameId = req.params.id
    const { winnerId } = req.body
    
    const game = storage.getGame(gameId)
    if (!game) {
      return res.status(404).json({ error: 'Partie non trouvée' })
    }
    
    if (game.status === 'completed') {
      return res.status(400).json({ error: 'Cette partie est déjà terminée' })
    }
    
    // Calculer les gains et commission
    const totalPot = game.betAmount * 2
    const adminCommission = totalPot * 0.2 // 20% pour l'admin
    const winnerEarnings = totalPot * 0.8 // 80% pour le gagnant
    
    // Mettre à jour la partie
    const updatedGame = storage.updateGame(gameId, {
      winnerId,
      winnerEarnings,
      adminCommission,
      status: 'completed'
    })
    
    // Mettre à jour les soldes des joueurs
    const player1 = storage.getPlayer(game.player1Id)!
    const player2 = storage.getPlayer(game.player2Id)!
    
    // Déduire la mise des deux joueurs
    storage.updatePlayer(game.player1Id, {
      balance: player1.balance - game.betAmount,
      totalGames: player1.totalGames + 1
    })
    
    storage.updatePlayer(game.player2Id, {
      balance: player2.balance - game.betAmount,
      totalGames: player2.totalGames + 1
    })
    
    // Ajouter les gains au gagnant
    const winner = storage.getPlayer(winnerId)!
    storage.updatePlayer(winnerId, {
      balance: winner.balance + winnerEarnings,
      totalWins: winner.totalWins + 1,
      totalEarnings: winner.totalEarnings + winnerEarnings
    })
    
    // Créer les transactions
    storage.createTransaction({
      playerId: game.player1Id,
      type: winnerId === game.player1Id ? 'win' : 'loss',
      amount: winnerId === game.player1Id ? winnerEarnings : -game.betAmount,
      status: 'completed'
    })
    
    storage.createTransaction({
      playerId: game.player2Id,
      type: winnerId === game.player2Id ? 'win' : 'loss',
      amount: winnerId === game.player2Id ? winnerEarnings : -game.betAmount,
      status: 'completed'
    })
    
    res.json(updatedGame)
  } catch (error) {
    res.status(500).json({ error: 'Erreur lors de la finalisation de la partie' })
  }
})

// Transactions routes
router.get('/api/transactions', (req, res) => {
  const transactions = storage.getAllTransactions()
  res.json(transactions)
})

router.get('/api/players/:playerId/transactions', (req, res) => {
  const transactions = storage.getPlayerTransactions(req.params.playerId)
  res.json(transactions)
})

router.post('/api/transactions', (req, res) => {
  try {
    const transactionData = insertTransactionSchema.parse(req.body)
    const transaction = storage.createTransaction(transactionData)
    res.status(201).json(transaction)
  } catch (error) {
    res.status(400).json({ error: 'Données invalides' })
  }
})

router.patch('/api/transactions/:id', (req, res) => {
  try {
    const updates = req.body
    const transaction = storage.updateTransaction(req.params.id, updates)
    if (!transaction) {
      return res.status(404).json({ error: 'Transaction non trouvée' })
    }
    res.json(transaction)
  } catch (error) {
    res.status(400).json({ error: 'Données invalides' })
  }
})

// Route pour les statistiques du leaderboard
router.get('/api/leaderboard', (req, res) => {
  const players = storage.getAllPlayers()
  const leaderboard = players
    .map(player => ({
      id: player.id,
      username: player.username,
      totalWins: player.totalWins,
      totalGames: player.totalGames,
      totalEarnings: player.totalEarnings,
      winRate: player.totalGames > 0 ? (player.totalWins / player.totalGames * 100).toFixed(1) : '0'
    }))
    .sort((a, b) => b.totalWins - a.totalWins)
  
  res.json(leaderboard)
})

export default router