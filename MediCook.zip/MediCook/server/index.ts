import express, { Express } from 'express'
import cors from 'cors'
import routes from './routes.js'

const app: Express = express()
const PORT = process.env.PORT || 3000

// Middleware
app.use(cors())
app.use(express.json())

// API routes
app.use(routes)

app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚀 Serveur démarré sur le port ${PORT}`)
  console.log(`🏎️ Jeu de course TRX disponible sur http://localhost:${PORT}`)
})