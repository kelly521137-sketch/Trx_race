import { Player, Game, Transaction } from '../shared/schema.js'

export interface IStorage {
  // Players
  getPlayer(id: string): Player | undefined
  getPlayerByUsername(username: string): Player | undefined
  createPlayer(player: Omit<Player, 'id' | 'createdAt'>): Player
  updatePlayer(id: string, updates: Partial<Player>): Player | undefined
  getAllPlayers(): Player[]
  
  // Games
  getGame(id: string): Game | undefined
  createGame(game: Omit<Game, 'id' | 'gameDate'>): Game
  updateGame(id: string, updates: Partial<Game>): Game | undefined
  getPlayerGames(playerId: string): Game[]
  getAllGames(): Game[]
  
  // Transactions
  getTransaction(id: string): Transaction | undefined
  createTransaction(transaction: Omit<Transaction, 'id' | 'date'>): Transaction
  updateTransaction(id: string, updates: Partial<Transaction>): Transaction | undefined
  getPlayerTransactions(playerId: string): Transaction[]
  getAllTransactions(): Transaction[]
}

export class MemStorage implements IStorage {
  private players: Map<string, Player> = new Map()
  private games: Map<string, Game> = new Map()
  private transactions: Map<string, Transaction> = new Map()
  
  constructor() {
    // Données d'exemple pour tester
    this.seedData()
  }
  
  private generateId(): string {
    return Math.random().toString(36).substr(2, 9)
  }
  
  private seedData() {
    // Créer quelques joueurs d'exemple
    const player1: Player = {
      id: 'player1',
      username: 'CryptoRacer',
      balance: 1500,
      totalWins: 12,
      totalGames: 25,
      totalEarnings: 2400,
      createdAt: new Date()
    }
    
    const player2: Player = {
      id: 'player2',
      username: 'TronSpeedster',
      balance: 2300,
      totalWins: 18,
      totalGames: 30,
      totalEarnings: 3200,
      createdAt: new Date()
    }
    
    this.players.set(player1.id, player1)
    this.players.set(player2.id, player2)
  }
  
  // Players
  getPlayer(id: string): Player | undefined {
    return this.players.get(id)
  }
  
  getPlayerByUsername(username: string): Player | undefined {
    return Array.from(this.players.values()).find(p => p.username === username)
  }
  
  createPlayer(playerData: Omit<Player, 'id' | 'createdAt'>): Player {
    const player: Player = {
      ...playerData,
      id: this.generateId(),
      createdAt: new Date()
    }
    this.players.set(player.id, player)
    return player
  }
  
  updatePlayer(id: string, updates: Partial<Player>): Player | undefined {
    const player = this.players.get(id)
    if (!player) return undefined
    
    const updatedPlayer = { ...player, ...updates }
    this.players.set(id, updatedPlayer)
    return updatedPlayer
  }
  
  getAllPlayers(): Player[] {
    return Array.from(this.players.values())
  }
  
  // Games
  getGame(id: string): Game | undefined {
    return this.games.get(id)
  }
  
  createGame(gameData: Omit<Game, 'id' | 'gameDate'>): Game {
    const game: Game = {
      ...gameData,
      id: this.generateId(),
      gameDate: new Date()
    }
    this.games.set(game.id, game)
    return game
  }
  
  updateGame(id: string, updates: Partial<Game>): Game | undefined {
    const game = this.games.get(id)
    if (!game) return undefined
    
    const updatedGame = { ...game, ...updates }
    this.games.set(id, updatedGame)
    return updatedGame
  }
  
  getPlayerGames(playerId: string): Game[] {
    return Array.from(this.games.values()).filter(
      g => g.player1Id === playerId || g.player2Id === playerId
    )
  }
  
  getAllGames(): Game[] {
    return Array.from(this.games.values())
  }
  
  // Transactions
  getTransaction(id: string): Transaction | undefined {
    return this.transactions.get(id)
  }
  
  createTransaction(transactionData: Omit<Transaction, 'id' | 'date'>): Transaction {
    const transaction: Transaction = {
      ...transactionData,
      id: this.generateId(),
      date: new Date()
    }
    this.transactions.set(transaction.id, transaction)
    return transaction
  }
  
  updateTransaction(id: string, updates: Partial<Transaction>): Transaction | undefined {
    const transaction = this.transactions.get(id)
    if (!transaction) return undefined
    
    const updatedTransaction = { ...transaction, ...updates }
    this.transactions.set(id, updatedTransaction)
    return updatedTransaction
  }
  
  getPlayerTransactions(playerId: string): Transaction[] {
    return Array.from(this.transactions.values()).filter(
      t => t.playerId === playerId
    )
  }
  
  getAllTransactions(): Transaction[] {
    return Array.from(this.transactions.values())
  }
}

export const storage = new MemStorage()