import { z } from 'zod'

// Types pour le jeu de course TRX
export const playerSchema = z.object({
  id: z.string(),
  username: z.string().min(1),
  balance: z.number().default(1000), // Solde TRX fictif
  totalWins: z.number().default(0),
  totalGames: z.number().default(0),
  totalEarnings: z.number().default(0),
  createdAt: z.date().default(() => new Date()),
})

export const gameSchema = z.object({
  id: z.string(),
  player1Id: z.string(),
  player2Id: z.string(),
  player1Car: z.enum(['blue', 'red', 'green']),
  player2Car: z.enum(['blue', 'red', 'green']),
  winnerId: z.string(),
  betAmount: z.number().min(10), // Mise minimum 10 TRX
  winnerEarnings: z.number(),
  adminCommission: z.number(),
  gameDate: z.date().default(() => new Date()),
  status: z.enum(['waiting', 'in_progress', 'completed']).default('waiting'),
})

export const transactionSchema = z.object({
  id: z.string(),
  playerId: z.string(),
  type: z.enum(['deposit', 'withdrawal', 'win', 'loss']),
  amount: z.number(),
  status: z.enum(['pending', 'completed', 'rejected']).default('pending'),
  date: z.date().default(() => new Date()),
})

// Types TypeScript inférés
export type Player = z.infer<typeof playerSchema>
export type Game = z.infer<typeof gameSchema>
export type Transaction = z.infer<typeof transactionSchema>

// Schémas d'insertion pour les formulaires
export const insertPlayerSchema = playerSchema.omit({ id: true, createdAt: true })

export const insertGameSchema = gameSchema.omit({ id: true, gameDate: true })

export const insertTransactionSchema = transactionSchema.omit({ id: true, date: true })

export type InsertPlayer = z.infer<typeof insertPlayerSchema>
export type InsertGame = z.infer<typeof insertGameSchema>
export type InsertTransaction = z.infer<typeof insertTransactionSchema>