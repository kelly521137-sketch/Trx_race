import { useState, useEffect } from 'react'
import { useQuery, useMutation } from '@tanstack/react-query'
import { Car, Clock, Trophy, Zap } from 'lucide-react'
import { queryClient, apiRequest } from '@/lib/queryClient'
import type { Player, Game } from '../../../shared/schema'

type CarColor = 'blue' | 'red' | 'green'

interface GameState {
  phase: 'waiting' | 'selecting' | 'racing' | 'finished'
  timeLeft: number
  player1Car?: CarColor
  player2Car?: CarColor
  winner?: string
  raceProgress: number
}

export default function GamePage() {
  const [gameState, setGameState] = useState<GameState>({
    phase: 'waiting',
    timeLeft: 20,
    raceProgress: 0
  })
  const [selectedCar, setSelectedCar] = useState<CarColor>()
  const [currentPlayer] = useState('player1') // Simulation - en vrai ce serait l'ID du joueur connecté
  const [betAmount] = useState(100) // Mise fixe pour la démo

  // Simulation des données joueur (en vrai ce serait récupéré via une session)
  const { data: player } = useQuery({
    queryKey: ['/api/players/player1'],
    enabled: false // Désactivé pour la démo
  })

  const simulatedPlayer: Player = {
    id: 'player1',
    username: 'CryptoRacer',
    balance: 1500,
    totalWins: 12,
    totalGames: 25,
    totalEarnings: 2400,
    createdAt: new Date()
  }

  // Démarre le timer de sélection
  useEffect(() => {
    if (gameState.phase === 'selecting' && gameState.timeLeft > 0) {
      const timer = setTimeout(() => {
        setGameState(prev => ({ ...prev, timeLeft: prev.timeLeft - 1 }))
      }, 1000)
      return () => clearTimeout(timer)
    } else if (gameState.phase === 'selecting' && gameState.timeLeft === 0) {
      // Temps écoulé - attribution automatique
      if (!selectedCar) {
        const randomCar: CarColor = ['blue', 'red', 'green'][Math.floor(Math.random() * 3)] as CarColor
        setSelectedCar(randomCar)
      }
      startRace()
    }
  }, [gameState.phase, gameState.timeLeft, selectedCar])

  const selectCar = (car: CarColor) => {
    if (gameState.phase !== 'selecting') return
    setSelectedCar(car)
  }

  const startGame = () => {
    setGameState({
      phase: 'selecting',
      timeLeft: 20,
      raceProgress: 0
    })
    setSelectedCar(undefined)
  }

  const startRace = () => {
    // Simulation : l'autre joueur choisit une voiture différente
    const availableCars = ['blue', 'red', 'green'].filter(c => c !== selectedCar) as CarColor[]
    const otherPlayerCar = availableCars[Math.floor(Math.random() * availableCars.length)]
    
    setGameState(prev => ({
      ...prev,
      phase: 'racing',
      player1Car: selectedCar,
      player2Car: otherPlayerCar,
      raceProgress: 0
    }))

    // Animation de la course
    const raceTimer = setInterval(() => {
      setGameState(prev => {
        const newProgress = prev.raceProgress + Math.random() * 10
        if (newProgress >= 100) {
          clearInterval(raceTimer)
          // Déterminer le gagnant aléatoirement
          const isPlayer1Winner = Math.random() > 0.5
          return {
            ...prev,
            phase: 'finished',
            raceProgress: 100,
            winner: isPlayer1Winner ? 'player1' : 'player2'
          }
        }
        return { ...prev, raceProgress: newProgress }
      })
    }, 100)
  }

  const resetGame = () => {
    setGameState({
      phase: 'waiting',
      timeLeft: 20,
      raceProgress: 0
    })
    setSelectedCar(undefined)
  }

  const getCarDisplay = (color: CarColor) => {
    const colors = {
      blue: 'bg-blue-500',
      red: 'bg-red-500',
      green: 'bg-green-500'
    }
    return (
      <div className={`w-16 h-8 ${colors[color]} rounded-lg shadow-lg race-car`}>
        <div className="w-full h-full bg-gradient-to-r from-white/20 to-transparent rounded-lg"></div>
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto">
      {/* Header avec infos joueur */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-800 dark:text-white">
              Course TRX - 2 Joueurs
            </h1>
            <p className="text-gray-600 dark:text-gray-300">
              Mise: {betAmount} TRX | Gain possible: {betAmount * 2 * 0.8} TRX
            </p>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-500 dark:text-gray-400">Votre solde</p>
            <p className="text-2xl font-bold text-primary">
              {simulatedPlayer.balance} TRX
            </p>
          </div>
        </div>
      </div>

      {/* Phase d'attente */}
      {gameState.phase === 'waiting' && (
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 text-center">
          <Car className="h-16 w-16 text-primary mx-auto mb-4" />
          <h2 className="text-3xl font-bold mb-4 text-gray-800 dark:text-white">
            Prêt à courir ?
          </h2>
          <p className="text-gray-600 dark:text-gray-300 mb-8">
            Cliquez sur "Démarrer la partie" pour commencer une course à 2 joueurs.
          </p>
          <button
            onClick={startGame}
            className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-4 rounded-lg text-lg font-semibold transition-all duration-200"
            data-testid="button-start-game"
          >
            <Zap className="inline-block mr-2 h-5 w-5" />
            Démarrer la partie
          </button>
        </div>
      )}

      {/* Phase de sélection */}
      {gameState.phase === 'selecting' && (
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8">
          <div className="text-center mb-8">
            <div className="flex items-center justify-center mb-4">
              <Clock className="h-8 w-8 text-orange-500 mr-2" />
              <span className="text-3xl font-bold text-orange-500">
                {gameState.timeLeft}s
              </span>
            </div>
            <h2 className="text-2xl font-bold mb-2 text-gray-800 dark:text-white">
              Choisissez votre voiture !
            </h2>
            <p className="text-gray-600 dark:text-gray-300">
              Vous avez {gameState.timeLeft} secondes pour faire votre choix.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {(['blue', 'red', 'green'] as CarColor[]).map((color) => (
              <button
                key={color}
                onClick={() => selectCar(color)}
                className={`p-6 rounded-xl border-2 transition-all duration-200 ${
                  selectedCar === color
                    ? 'border-primary bg-primary/10 scale-105'
                    : 'border-gray-300 dark:border-gray-600 hover:border-primary hover:scale-105'
                }`}
                data-testid={`button-select-car-${color}`}
              >
                <div className="flex flex-col items-center space-y-4">
                  {getCarDisplay(color)}
                  <span className="text-lg font-semibold capitalize text-gray-800 dark:text-white">
                    Voiture {color === 'blue' ? 'Bleue' : color === 'red' ? 'Rouge' : 'Verte'}
                  </span>
                  {selectedCar === color && (
                    <div className="bg-primary text-primary-foreground px-3 py-1 rounded-full text-sm font-medium">
                      Sélectionnée
                    </div>
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Phase de course */}
      {gameState.phase === 'racing' && (
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8">
          <h2 className="text-2xl font-bold text-center mb-8 text-gray-800 dark:text-white">
            Course en cours !
          </h2>
          
          <div className="space-y-6">
            {/* Piste Joueur 1 */}
            <div className="bg-gray-100 dark:bg-gray-700 rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="font-semibold text-gray-800 dark:text-white">
                  Vous ({selectedCar})
                </span>
              </div>
              <div className="h-12 bg-gray-300 dark:bg-gray-600 rounded-lg relative overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-yellow-400 to-orange-500 transition-all duration-100"
                  style={{ width: `${gameState.raceProgress}%` }}
                ></div>
                <div
                  className="absolute top-2 transition-all duration-100"
                  style={{ left: `${Math.min(gameState.raceProgress, 95)}%` }}
                >
                  {gameState.player1Car && getCarDisplay(gameState.player1Car)}
                </div>
              </div>
            </div>

            {/* Piste Joueur 2 */}
            <div className="bg-gray-100 dark:bg-gray-700 rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="font-semibold text-gray-800 dark:text-white">
                  Adversaire ({gameState.player2Car})
                </span>
              </div>
              <div className="h-12 bg-gray-300 dark:bg-gray-600 rounded-lg relative overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-yellow-400 to-orange-500 transition-all duration-100"
                  style={{ width: `${gameState.raceProgress + Math.random() * 10 - 5}%` }}
                ></div>
                <div
                  className="absolute top-2 transition-all duration-100"
                  style={{ left: `${Math.min(gameState.raceProgress + Math.random() * 10 - 5, 95)}%` }}
                >
                  {gameState.player2Car && getCarDisplay(gameState.player2Car)}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Phase terminée */}
      {gameState.phase === 'finished' && (
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 text-center">
          <Trophy className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
          <h2 className="text-3xl font-bold mb-4 text-gray-800 dark:text-white">
            Course terminée !
          </h2>
          
          {gameState.winner === 'player1' ? (
            <div className="text-center">
              <p className="text-2xl font-bold text-green-600 mb-2">
                🎉 Félicitations ! Vous avez gagné !
              </p>
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                Vous remportez {betAmount * 2 * 0.8} TRX (80% du pot de {betAmount * 2} TRX)
              </p>
            </div>
          ) : (
            <div className="text-center">
              <p className="text-2xl font-bold text-red-600 mb-2">
                😔 Vous avez perdu cette fois...
              </p>
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                Votre adversaire remporte {betAmount * 2 * 0.8} TRX
              </p>
            </div>
          )}

          <div className="space-y-4 sm:space-y-0 sm:space-x-4 sm:flex sm:justify-center">
            <button
              onClick={resetGame}
              className="w-full sm:w-auto bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-3 rounded-lg font-semibold transition-all duration-200"
              data-testid="button-play-again"
            >
              Rejouer
            </button>
            <button
              onClick={() => window.location.href = '/profile'}
              className="w-full sm:w-auto bg-secondary hover:bg-secondary/80 text-secondary-foreground px-8 py-3 rounded-lg font-semibold transition-all duration-200"
              data-testid="button-view-profile"
            >
              Voir mon profil
            </button>
          </div>
        </div>
      )}
    </div>
  )
}