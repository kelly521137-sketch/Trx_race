import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { User, Wallet, TrendingUp, TrendingDown, Plus, Minus } from 'lucide-react'
import type { Player, Transaction } from '../../../shared/schema'

export default function ProfilePage() {
  const [showDepositModal, setShowDepositModal] = useState(false)
  const [showWithdrawModal, setShowWithdrawModal] = useState(false)

  // Simulation des données (en vrai ce serait récupéré via l'API)
  const simulatedPlayer: Player = {
    id: 'player1',
    username: 'CryptoRacer',
    balance: 1500,
    totalWins: 12,
    totalGames: 25,
    totalEarnings: 2400,
    createdAt: new Date('2024-01-15')
  }

  const simulatedTransactions: Transaction[] = [
    {
      id: '1',
      playerId: 'player1',
      type: 'win',
      amount: 160,
      status: 'completed',
      date: new Date('2024-12-06T10:30:00')
    },
    {
      id: '2',
      playerId: 'player1',
      type: 'loss',
      amount: -100,
      status: 'completed',
      date: new Date('2024-12-06T09:15:00')
    },
    {
      id: '3',
      playerId: 'player1',
      type: 'deposit',
      amount: 500,
      status: 'completed',
      date: new Date('2024-12-05T14:20:00')
    },
    {
      id: '4',
      playerId: 'player1',
      type: 'win',
      amount: 320,
      status: 'completed',
      date: new Date('2024-12-05T11:45:00')
    },
    {
      id: '5',
      playerId: 'player1',
      type: 'withdrawal',
      amount: -200,
      status: 'completed',
      date: new Date('2024-12-04T16:30:00')
    }
  ]

  const winRate = simulatedPlayer.totalGames > 0 
    ? (simulatedPlayer.totalWins / simulatedPlayer.totalGames * 100).toFixed(1)
    : '0'

  const getTransactionIcon = (type: Transaction['type']) => {
    switch (type) {
      case 'win':
        return <TrendingUp className="h-5 w-5 text-green-500" />
      case 'loss':
        return <TrendingDown className="h-5 w-5 text-red-500" />
      case 'deposit':
        return <Plus className="h-5 w-5 text-blue-500" />
      case 'withdrawal':
        return <Minus className="h-5 w-5 text-orange-500" />
    }
  }

  const getTransactionLabel = (type: Transaction['type']) => {
    switch (type) {
      case 'win':
        return 'Gain de course'
      case 'loss':
        return 'Perte de course'
      case 'deposit':
        return 'Dépôt'
      case 'withdrawal':
        return 'Retrait'
    }
  }

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date)
  }

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header Profil */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8">
        <div className="flex items-center space-x-6">
          <div className="bg-primary text-primary-foreground w-20 h-20 rounded-full flex items-center justify-center">
            <User className="h-10 w-10" />
          </div>
          <div className="flex-1">
            <h1 className="text-3xl font-bold text-gray-800 dark:text-white mb-2">
              {simulatedPlayer.username}
            </h1>
            <p className="text-gray-600 dark:text-gray-300">
              Membre depuis {formatDate(simulatedPlayer.createdAt)}
            </p>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Solde TRX</p>
            <p className="text-3xl font-bold text-primary" data-testid="text-balance">
              {simulatedPlayer.balance}
            </p>
          </div>
        </div>
      </div>

      {/* Statistiques et Actions */}
      <div className="grid lg:grid-cols-2 gap-8">
        {/* Statistiques */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
          <h2 className="text-2xl font-bold mb-6 text-gray-800 dark:text-white">
            Statistiques de jeu
          </h2>
          
          <div className="grid grid-cols-2 gap-6">
            <div className="text-center p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <p className="text-3xl font-bold text-blue-600 dark:text-blue-400" data-testid="text-total-wins">
                {simulatedPlayer.totalWins}
              </p>
              <p className="text-sm text-gray-600 dark:text-gray-300">Victoires</p>
            </div>
            
            <div className="text-center p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <p className="text-3xl font-bold text-green-600 dark:text-green-400" data-testid="text-total-games">
                {simulatedPlayer.totalGames}
              </p>
              <p className="text-sm text-gray-600 dark:text-gray-300">Parties jouées</p>
            </div>
            
            <div className="text-center p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
              <p className="text-3xl font-bold text-purple-600 dark:text-purple-400" data-testid="text-win-rate">
                {winRate}%
              </p>
              <p className="text-sm text-gray-600 dark:text-gray-300">Taux de victoire</p>
            </div>
            
            <div className="text-center p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
              <p className="text-3xl font-bold text-yellow-600 dark:text-yellow-400" data-testid="text-total-earnings">
                {simulatedPlayer.totalEarnings}
              </p>
              <p className="text-sm text-gray-600 dark:text-gray-300">Gains totaux</p>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
          <h2 className="text-2xl font-bold mb-6 text-gray-800 dark:text-white">
            Gestion du solde
          </h2>
          
          <div className="space-y-4">
            <button
              onClick={() => setShowDepositModal(true)}
              className="w-full bg-green-500 hover:bg-green-600 text-white p-4 rounded-lg font-semibold transition-colors flex items-center justify-center space-x-2"
              data-testid="button-deposit"
            >
              <Plus className="h-5 w-5" />
              <span>Déposer des TRX</span>
            </button>
            
            <button
              onClick={() => setShowWithdrawModal(true)}
              className="w-full bg-orange-500 hover:bg-orange-600 text-white p-4 rounded-lg font-semibold transition-colors flex items-center justify-center space-x-2"
              data-testid="button-withdraw"
            >
              <Minus className="h-5 w-5" />
              <span>Retirer des TRX</span>
            </button>
          </div>
          
          <div className="mt-6 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
            <p className="text-sm text-gray-600 dark:text-gray-300">
              <strong>Note:</strong> Dans cette version de démonstration, les dépôts et retraits sont simulés. 
              Aucune transaction blockchain réelle n'est effectuée.
            </p>
          </div>
        </div>
      </div>

      {/* Historique des transactions */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
        <h2 className="text-2xl font-bold mb-6 text-gray-800 dark:text-white">
          Dernières transactions
        </h2>
        
        <div className="space-y-4">
          {simulatedTransactions.map((transaction) => (
            <div
              key={transaction.id}
              className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg"
              data-testid={`transaction-${transaction.id}`}
            >
              <div className="flex items-center space-x-4">
                {getTransactionIcon(transaction.type)}
                <div>
                  <p className="font-semibold text-gray-800 dark:text-white">
                    {getTransactionLabel(transaction.type)}
                  </p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    {formatDate(transaction.date)}
                  </p>
                </div>
              </div>
              
              <div className="text-right">
                <p className={`font-bold text-lg ${
                  transaction.amount > 0 
                    ? 'text-green-600 dark:text-green-400' 
                    : 'text-red-600 dark:text-red-400'
                }`}>
                  {transaction.amount > 0 ? '+' : ''}{transaction.amount} TRX
                </p>
                <p className="text-sm text-gray-500 dark:text-gray-400 capitalize">
                  {transaction.status}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Modals de dépôt/retrait simulés */}
      {showDepositModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 max-w-md w-full mx-4">
            <h3 className="text-xl font-bold mb-4 text-gray-800 dark:text-white">
              Simulation de dépôt
            </h3>
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              Dans une version réelle, vous pourriez déposer des TRX depuis votre wallet.
            </p>
            <button
              onClick={() => setShowDepositModal(false)}
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground p-3 rounded-lg font-semibold"
              data-testid="button-close-deposit"
            >
              Fermer
            </button>
          </div>
        </div>
      )}

      {showWithdrawModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white dark:bg-gray-800 rounded-xl p-6 max-w-md w-full mx-4">
            <h3 className="text-xl font-bold mb-4 text-gray-800 dark:text-white">
              Simulation de retrait
            </h3>
            <p className="text-gray-600 dark:text-gray-300 mb-6">
              Dans une version réelle, vous pourriez retirer des TRX vers votre wallet.
            </p>
            <button
              onClick={() => setShowWithdrawModal(false)}
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground p-3 rounded-lg font-semibold"
              data-testid="button-close-withdraw"
            >
              Fermer
            </button>
          </div>
        </div>
      )}
    </div>
  )
}