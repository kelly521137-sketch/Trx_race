import { Trophy, Medal, Award, TrendingUp } from 'lucide-react'

interface LeaderboardEntry {
  id: string
  username: string
  totalWins: number
  totalGames: number
  totalEarnings: number
  winRate: string
}

export default function LeaderboardPage() {
  // Simulation des données du leaderboard
  const leaderboardData: LeaderboardEntry[] = [
    {
      id: '1',
      username: 'SpeedDemon',
      totalWins: 45,
      totalGames: 60,
      totalEarnings: 8900,
      winRate: '75.0'
    },
    {
      id: '2',
      username: 'CryptoKing',
      totalWins: 38,
      totalGames: 55,
      totalEarnings: 7200,
      winRate: '69.1'
    },
    {
      id: '3',
      username: 'RaceChampion',
      totalWins: 42,
      totalGames: 62,
      totalEarnings: 6800,
      winRate: '67.7'
    },
    {
      id: '4',
      username: 'TronMaster',
      totalWins: 29,
      totalGames: 45,
      totalEarnings: 5400,
      winRate: '64.4'
    },
    {
      id: '5',
      username: 'FastFury',
      totalWins: 33,
      totalGames: 52,
      totalEarnings: 4900,
      winRate: '63.5'
    },
    {
      id: '6',
      username: 'VelocityViper',
      totalWins: 27,
      totalGames: 44,
      totalEarnings: 4200,
      winRate: '61.4'
    },
    {
      id: '7',
      username: 'NitroNinja',
      totalWins: 24,
      totalGames: 41,
      totalEarnings: 3800,
      winRate: '58.5'
    },
    {
      id: '8',
      username: 'TurboTiger',
      totalWins: 21,
      totalGames: 38,
      totalEarnings: 3200,
      winRate: '55.3'
    },
    {
      id: '9',
      username: 'RocketRacer',
      totalWins: 18,
      totalGames: 35,
      totalEarnings: 2900,
      winRate: '51.4'
    },
    {
      id: '10',
      username: 'CryptoRacer',
      totalWins: 12,
      totalGames: 25,
      totalEarnings: 2400,
      winRate: '48.0'
    }
  ]

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="h-6 w-6 text-yellow-500" />
      case 2:
        return <Medal className="h-6 w-6 text-gray-400" />
      case 3:
        return <Award className="h-6 w-6 text-amber-600" />
      default:
        return <span className="text-lg font-bold text-gray-500 dark:text-gray-400">#{rank}</span>
    }
  }

  const getRankBadge = (rank: number) => {
    switch (rank) {
      case 1:
        return 'bg-gradient-to-r from-yellow-400 to-yellow-600'
      case 2:
        return 'bg-gradient-to-r from-gray-300 to-gray-500'
      case 3:
        return 'bg-gradient-to-r from-amber-400 to-amber-600'
      default:
        return 'bg-gray-100 dark:bg-gray-700'
    }
  }

  return (
    <div className="max-w-6xl mx-auto">
      {/* Header */}
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold text-gray-800 dark:text-white mb-4">
          🏆 Classement des Champions
        </h1>
        <p className="text-xl text-gray-600 dark:text-gray-300">
          Les meilleurs pilotes TRX classés par nombre de victoires
        </p>
      </div>

      {/* Podium */}
      <div className="grid md:grid-cols-3 gap-6 mb-12">
        {leaderboardData.slice(0, 3).map((player, index) => {
          const rank = index + 1
          return (
            <div
              key={player.id}
              className={`text-center p-6 rounded-xl shadow-lg ${
                rank === 1 
                  ? 'bg-gradient-to-br from-yellow-50 to-yellow-100 dark:from-yellow-900/20 dark:to-yellow-800/20 border-2 border-yellow-300'
                  : rank === 2
                  ? 'bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-700 border-2 border-gray-300'
                  : 'bg-gradient-to-br from-amber-50 to-amber-100 dark:from-amber-900/20 dark:to-amber-800/20 border-2 border-amber-300'
              }`}
              data-testid={`podium-${rank}`}
            >
              <div className="flex justify-center mb-4">
                {getRankIcon(rank)}
              </div>
              
              <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-2">
                {player.username}
              </h3>
              
              <div className="space-y-2">
                <p className="text-2xl font-bold text-primary">
                  {player.totalWins} victoires
                </p>
                <p className="text-gray-600 dark:text-gray-300">
                  {player.totalEarnings} TRX gagnés
                </p>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  Taux de victoire: {player.winRate}%
                </p>
              </div>
            </div>
          )
        })}
      </div>

      {/* Tableau complet */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden">
        <div className="px-6 py-4 bg-gray-50 dark:bg-gray-700 border-b border-gray-200 dark:border-gray-600">
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white">
            Classement complet
          </h2>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 dark:bg-gray-700">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Rang
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Joueur
                </th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Victoires
                </th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Parties
                </th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Taux victoire
                </th>
                <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Gains totaux
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200 dark:divide-gray-600">
              {leaderboardData.map((player, index) => {
                const rank = index + 1
                return (
                  <tr
                    key={player.id}
                    className={`hover:bg-gray-50 dark:hover:bg-gray-700 ${
                      rank <= 3 ? 'bg-gradient-to-r from-primary/5 to-transparent' : ''
                    }`}
                    data-testid={`leaderboard-row-${rank}`}
                  >
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className={`flex items-center justify-center w-8 h-8 rounded-full ${getRankBadge(rank)}`}>
                        {rank <= 3 ? (
                          getRankIcon(rank)
                        ) : (
                          <span className="text-sm font-bold text-gray-600 dark:text-gray-300">
                            {rank}
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="bg-primary text-primary-foreground w-10 h-10 rounded-full flex items-center justify-center mr-3">
                          {player.username.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <div className="text-sm font-medium text-gray-800 dark:text-white">
                            {player.username}
                          </div>
                          {rank <= 3 && (
                            <div className="text-xs text-gray-500 dark:text-gray-400">
                              Champion
                            </div>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      <span className="text-lg font-bold text-primary" data-testid={`wins-${rank}`}>
                        {player.totalWins}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center text-gray-600 dark:text-gray-300">
                      {player.totalGames}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      <div className="flex items-center justify-center">
                        <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                        <span className="text-green-600 dark:text-green-400 font-semibold">
                          {player.winRate}%
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      <span className="text-yellow-600 dark:text-yellow-400 font-bold" data-testid={`earnings-${rank}`}>
                        {player.totalEarnings} TRX
                      </span>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Stats générales */}
      <div className="mt-12 grid md:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 text-center">
          <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-2">
            Total des parties
          </h3>
          <p className="text-3xl font-bold text-primary">
            {leaderboardData.reduce((sum, player) => sum + player.totalGames, 0)}
          </p>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 text-center">
          <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-2">
            TRX distribués
          </h3>
          <p className="text-3xl font-bold text-yellow-600 dark:text-yellow-400">
            {leaderboardData.reduce((sum, player) => sum + player.totalEarnings, 0)}
          </p>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 text-center">
          <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-2">
            Joueurs actifs
          </h3>
          <p className="text-3xl font-bold text-green-600 dark:text-green-400">
            {leaderboardData.length}
          </p>
        </div>
      </div>
    </div>
  )
}