import { useState } from 'react'
import { Calendar, Filter, Car, Trophy, TrendingUp, TrendingDown } from 'lucide-react'
import type { Game } from '../../../shared/schema'

interface GameWithPlayers extends Game {
  player1Name: string
  player2Name: string
  isCurrentPlayer: boolean
}

export default function HistoryPage() {
  const [filter, setFilter] = useState<'all' | 'wins' | 'losses'>('all')

  // Simulation des données de l'historique
  const gameHistory: GameWithPlayers[] = [
    {
      id: '1',
      player1Id: 'player1',
      player2Id: 'player2',
      player1Car: 'blue',
      player2Car: 'red',
      winnerId: 'player1',
      betAmount: 100,
      winnerEarnings: 160,
      adminCommission: 40,
      gameDate: new Date('2024-12-06T10:30:00'),
      status: 'completed',
      player1Name: 'CryptoRacer',
      player2Name: 'SpeedDemon',
      isCurrentPlayer: true
    },
    {
      id: '2',
      player1Id: 'player1',
      player2Id: 'player3',
      player1Car: 'green',
      player2Car: 'blue',
      winnerId: 'player3',
      betAmount: 100,
      winnerEarnings: 160,
      adminCommission: 40,
      gameDate: new Date('2024-12-06T09:15:00'),
      status: 'completed',
      player1Name: 'CryptoRacer',
      player2Name: 'TurboKing',
      isCurrentPlayer: true
    },
    {
      id: '3',
      player1Id: 'player4',
      player2Id: 'player1',
      player1Car: 'red',
      player2Car: 'green',
      winnerId: 'player1',
      betAmount: 150,
      winnerEarnings: 240,
      adminCommission: 60,
      gameDate: new Date('2024-12-05T16:45:00'),
      status: 'completed',
      player1Name: 'VelocityRacer',
      player2Name: 'CryptoRacer',
      isCurrentPlayer: true
    },
    {
      id: '4',
      player1Id: 'player1',
      player2Id: 'player5',
      player1Car: 'blue',
      player2Car: 'red',
      winnerId: 'player5',
      betAmount: 80,
      winnerEarnings: 128,
      adminCommission: 32,
      gameDate: new Date('2024-12-05T14:20:00'),
      status: 'completed',
      player1Name: 'CryptoRacer',
      player2Name: 'NitroSpeed',
      isCurrentPlayer: true
    },
    {
      id: '5',
      player1Id: 'player6',
      player2Id: 'player1',
      player1Car: 'green',
      player2Car: 'blue',
      winnerId: 'player1',
      betAmount: 200,
      winnerEarnings: 320,
      adminCommission: 80,
      gameDate: new Date('2024-12-04T11:30:00'),
      status: 'completed',
      player1Name: 'RocketRider',
      player2Name: 'CryptoRacer',
      isCurrentPlayer: true
    },
    {
      id: '6',
      player1Id: 'player1',
      player2Id: 'player7',
      player1Car: 'red',
      player2Car: 'green',
      winnerId: 'player7',
      betAmount: 120,
      winnerEarnings: 192,
      adminCommission: 48,
      gameDate: new Date('2024-12-03T15:10:00'),
      status: 'completed',
      player1Name: 'CryptoRacer',
      player2Name: 'LightningBolt',
      isCurrentPlayer: true
    }
  ]

  const filteredGames = gameHistory.filter(game => {
    if (filter === 'wins') return game.winnerId === 'player1'
    if (filter === 'losses') return game.winnerId !== 'player1'
    return true
  })

  const getCarDisplay = (color: 'blue' | 'red' | 'green') => {
    const colors = {
      blue: 'bg-blue-500',
      red: 'bg-red-500',
      green: 'bg-green-500'
    }
    return (
      <div className={`w-8 h-4 ${colors[color]} rounded-sm shadow-sm`}>
        <div className="w-full h-full bg-gradient-to-r from-white/30 to-transparent rounded-sm"></div>
      </div>
    )
  }

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date)
  }

  const getTotalStats = () => {
    const wins = gameHistory.filter(g => g.winnerId === 'player1').length
    const totalGames = gameHistory.length
    const totalEarnings = gameHistory
      .filter(g => g.winnerId === 'player1')
      .reduce((sum, g) => sum + g.winnerEarnings, 0)
    const totalLosses = gameHistory
      .filter(g => g.winnerId !== 'player1')
      .reduce((sum, g) => sum + g.betAmount, 0)

    return { wins, totalGames, totalEarnings, totalLosses, netGains: totalEarnings - totalLosses }
  }

  const stats = getTotalStats()

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-800 dark:text-white mb-4">
          📊 Historique des courses
        </h1>
        <p className="text-xl text-gray-600 dark:text-gray-300">
          Consultez toutes vos parties passées et vos performances
        </p>
      </div>

      {/* Statistiques générales */}
      <div className="grid md:grid-cols-5 gap-4">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 text-center">
          <Trophy className="h-8 w-8 text-yellow-500 mx-auto mb-2" />
          <p className="text-2xl font-bold text-yellow-600 dark:text-yellow-400" data-testid="text-total-wins">
            {stats.wins}
          </p>
          <p className="text-sm text-gray-600 dark:text-gray-300">Victoires</p>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 text-center">
          <Calendar className="h-8 w-8 text-blue-500 mx-auto mb-2" />
          <p className="text-2xl font-bold text-blue-600 dark:text-blue-400" data-testid="text-total-games">
            {stats.totalGames}
          </p>
          <p className="text-sm text-gray-600 dark:text-gray-300">Parties</p>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 text-center">
          <TrendingUp className="h-8 w-8 text-green-500 mx-auto mb-2" />
          <p className="text-2xl font-bold text-green-600 dark:text-green-400" data-testid="text-win-rate">
            {stats.totalGames > 0 ? ((stats.wins / stats.totalGames) * 100).toFixed(1) : 0}%
          </p>
          <p className="text-sm text-gray-600 dark:text-gray-300">Taux victoire</p>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 text-center">
          <div className="text-green-500 mx-auto mb-2 text-2xl">💰</div>
          <p className="text-2xl font-bold text-green-600 dark:text-green-400" data-testid="text-total-earnings">
            +{stats.totalEarnings}
          </p>
          <p className="text-sm text-gray-600 dark:text-gray-300">Gains totaux</p>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 text-center">
          <TrendingDown className={`h-8 w-8 mx-auto mb-2 ${stats.netGains >= 0 ? 'text-green-500' : 'text-red-500'}`} />
          <p className={`text-2xl font-bold ${stats.netGains >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`} data-testid="text-net-gains">
            {stats.netGains >= 0 ? '+' : ''}{stats.netGains}
          </p>
          <p className="text-sm text-gray-600 dark:text-gray-300">Gains nets</p>
        </div>
      </div>

      {/* Filtres */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white">
            Historique détaillé
          </h2>
          
          <div className="flex items-center space-x-2">
            <Filter className="h-5 w-5 text-gray-500 dark:text-gray-400" />
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value as 'all' | 'wins' | 'losses')}
              className="bg-gray-100 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg px-3 py-2 text-gray-800 dark:text-white"
              data-testid="select-filter"
            >
              <option value="all">Toutes les parties</option>
              <option value="wins">Victoires uniquement</option>
              <option value="losses">Défaites uniquement</option>
            </select>
          </div>
        </div>

        {/* Liste des parties */}
        <div className="space-y-4">
          {filteredGames.map((game) => {
            const isWin = game.winnerId === 'player1'
            const opponent = game.player1Id === 'player1' ? game.player2Name : game.player1Name
            const myCard = game.player1Id === 'player1' ? game.player1Car : game.player2Car
            const opponentCar = game.player1Id === 'player1' ? game.player2Car : game.player1Car
            
            return (
              <div
                key={game.id}
                className={`p-6 rounded-lg border-2 transition-all ${
                  isWin 
                    ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800' 
                    : 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800'
                }`}
                data-testid={`game-${game.id}`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-6">
                    {/* Résultat */}
                    <div className="text-center">
                      {isWin ? (
                        <Trophy className="h-8 w-8 text-yellow-500 mx-auto mb-1" />
                      ) : (
                        <div className="h-8 w-8 mx-auto mb-1 text-2xl">💥</div>
                      )}
                      <p className={`text-sm font-semibold ${
                        isWin ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
                      }`}>
                        {isWin ? 'VICTOIRE' : 'DÉFAITE'}
                      </p>
                    </div>

                    {/* Voitures */}
                    <div className="flex items-center space-x-4">
                      <div className="text-center">
                        <p className="text-sm text-gray-600 dark:text-gray-300 mb-1">Vous</p>
                        {getCarDisplay(myCard)}
                        <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 capitalize">
                          {myCard === 'blue' ? 'Bleue' : myCard === 'red' ? 'Rouge' : 'Verte'}
                        </p>
                      </div>
                      
                      <div className="text-2xl">🆚</div>
                      
                      <div className="text-center">
                        <p className="text-sm text-gray-600 dark:text-gray-300 mb-1">{opponent}</p>
                        {getCarDisplay(opponentCar)}
                        <p className="text-xs text-gray-500 dark:text-gray-400 mt-1 capitalize">
                          {opponentCar === 'blue' ? 'Bleue' : opponentCar === 'red' ? 'Rouge' : 'Verte'}
                        </p>
                      </div>
                    </div>

                    {/* Détails de la partie */}
                    <div>
                      <p className="text-gray-800 dark:text-white font-semibold">
                        Mise: {game.betAmount} TRX
                      </p>
                      <p className="text-sm text-gray-600 dark:text-gray-300">
                        {formatDate(game.gameDate)}
                      </p>
                    </div>
                  </div>

                  {/* Gains/Pertes */}
                  <div className="text-right">
                    <p className={`text-2xl font-bold ${
                      isWin ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
                    }`}>
                      {isWin ? `+${game.winnerEarnings}` : `-${game.betAmount}`} TRX
                    </p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {isWin ? 'Gain net' : 'Perte'}
                    </p>
                  </div>
                </div>
              </div>
            )
          })}
        </div>

        {filteredGames.length === 0 && (
          <div className="text-center py-12">
            <Car className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-600 dark:text-gray-300 mb-2">
              Aucune partie trouvée
            </h3>
            <p className="text-gray-500 dark:text-gray-400">
              {filter === 'wins' 
                ? 'Vous n\'avez pas encore remporté de victoire avec ce filtre.'
                : filter === 'losses'
                ? 'Aucune défaite trouvée avec ce filtre.'
                : 'Aucune partie dans votre historique.'}
            </p>
          </div>
        )}
      </div>
    </div>
  )
}