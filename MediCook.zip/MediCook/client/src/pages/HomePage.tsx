import { Link } from 'wouter'
import { Car, Trophy, Zap, Users } from 'lucide-react'

export default function HomePage() {
  return (
    <div className="max-w-6xl mx-auto">
      {/* Hero Section */}
      <div className="text-center py-20">
        <div className="bounce-in">
          <h1 className="text-6xl font-bold text-gray-800 dark:text-white mb-6">
            <span className="text-primary">TRX</span> Racing
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto">
            Participez à des courses crypto passionnantes avec 2 joueurs ! 
            Choisissez votre voiture, pariez vos TRX et remportez 80% du pot total.
          </p>
        </div>
        
        <div className="space-y-4 sm:space-y-0 sm:space-x-4 sm:flex sm:justify-center">
          <Link href="/game">
            <button 
              className="w-full sm:w-auto bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-4 rounded-lg text-lg font-semibold transition-all duration-200 pulse-glow"
              data-testid="button-play-now"
            >
              <Car className="inline-block mr-2 h-5 w-5" />
              Jouer maintenant
            </button>
          </Link>
          
          <Link href="/leaderboard">
            <button 
              className="w-full sm:w-auto bg-secondary hover:bg-secondary/80 text-secondary-foreground px-8 py-4 rounded-lg text-lg font-semibold transition-all duration-200"
              data-testid="button-leaderboard"
            >
              <Trophy className="inline-block mr-2 h-5 w-5" />
              Voir le classement
            </button>
          </Link>
        </div>
      </div>

      {/* Features Grid */}
      <div className="grid md:grid-cols-3 gap-8 py-16">
        <div className="text-center p-6 bg-white dark:bg-gray-800 rounded-xl shadow-lg">
          <div className="bg-blue-100 dark:bg-blue-900 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <Users className="h-8 w-8 text-blue-600 dark:text-blue-400" />
          </div>
          <h3 className="text-xl font-semibold mb-3 text-gray-800 dark:text-white">
            Parties 2 Joueurs
          </h3>
          <p className="text-gray-600 dark:text-gray-300">
            Affrontez un autre joueur dans des courses épiques. Chaque partie oppose exactement 2 participants.
          </p>
        </div>

        <div className="text-center p-6 bg-white dark:bg-gray-800 rounded-xl shadow-lg">
          <div className="bg-green-100 dark:bg-green-900 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <Car className="h-8 w-8 text-green-600 dark:text-green-400" />
          </div>
          <h3 className="text-xl font-semibold mb-3 text-gray-800 dark:text-white">
            Choix de Voitures
          </h3>
          <p className="text-gray-600 dark:text-gray-300">
            Sélectionnez parmi 3 voitures : bleue, rouge ou verte. Vous avez 20 secondes pour choisir !
          </p>
        </div>

        <div className="text-center p-6 bg-white dark:bg-gray-800 rounded-xl shadow-lg">
          <div className="bg-yellow-100 dark:bg-yellow-900 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
            <Zap className="h-8 w-8 text-yellow-600 dark:text-yellow-400" />
          </div>
          <h3 className="text-xl font-semibold mb-3 text-gray-800 dark:text-white">
            Gains Instantanés
          </h3>
          <p className="text-gray-600 dark:text-gray-300">
            Le gagnant remporte 80% du pot total, l'admin prend 20%. Gains ajoutés immédiatement à votre solde.
          </p>
        </div>
      </div>

      {/* Game Rules */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 mb-16">
        <h2 className="text-3xl font-bold text-center mb-8 text-gray-800 dark:text-white">
          Comment jouer ?
        </h2>
        
        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-4">
            <div className="flex items-start space-x-4">
              <div className="bg-primary text-primary-foreground w-8 h-8 rounded-full flex items-center justify-center font-bold">
                1
              </div>
              <div>
                <h4 className="font-semibold text-gray-800 dark:text-white">Rejoignez une partie</h4>
                <p className="text-gray-600 dark:text-gray-300">Cliquez sur "Jouer maintenant" pour commencer une nouvelle partie à 2 joueurs.</p>
              </div>
            </div>
            
            <div className="flex items-start space-x-4">
              <div className="bg-primary text-primary-foreground w-8 h-8 rounded-full flex items-center justify-center font-bold">
                2
              </div>
              <div>
                <h4 className="font-semibold text-gray-800 dark:text-white">Choisissez votre voiture</h4>
                <p className="text-gray-600 dark:text-gray-300">Sélectionnez une voiture parmi bleue, rouge ou verte en 20 secondes max.</p>
              </div>
            </div>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-start space-x-4">
              <div className="bg-primary text-primary-foreground w-8 h-8 rounded-full flex items-center justify-center font-bold">
                3
              </div>
              <div>
                <h4 className="font-semibold text-gray-800 dark:text-white">Course automatique</h4>
                <p className="text-gray-600 dark:text-gray-300">Les voitures courent automatiquement avec un résultat aléatoire équitable.</p>
              </div>
            </div>
            
            <div className="flex items-start space-x-4">
              <div className="bg-primary text-primary-foreground w-8 h-8 rounded-full flex items-center justify-center font-bold">
                4
              </div>
              <div>
                <h4 className="font-semibold text-gray-800 dark:text-white">Récupérez vos gains</h4>
                <p className="text-gray-600 dark:text-gray-300">Le gagnant remporte 80% du pot, automatiquement ajouté au solde TRX.</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Bottom */}
      <div className="text-center py-16 bg-gradient-to-r from-primary/10 to-blue-500/10 rounded-xl">
        <h2 className="text-3xl font-bold mb-4 text-gray-800 dark:text-white">
          Prêt à gagner des TRX ?
        </h2>
        <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
          Rejoignez la course et montrez vos talents de pilote !
        </p>
        <Link href="/game">
          <button 
            className="bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-4 rounded-lg text-lg font-semibold transition-all duration-200"
            data-testid="button-start-racing"
          >
            Commencer à courir
          </button>
        </Link>
      </div>
    </div>
  )
}