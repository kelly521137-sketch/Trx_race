import { useState } from 'react'
import { DollarSign, Users, TrendingUp, Settings, Check, X, Clock } from 'lucide-react'
import type { Transaction, Player, Game } from '../../../shared/schema'

interface AdminStats {
  totalCommissions: number
  totalPlayers: number
  totalGames: number
  pendingTransactions: number
}

export default function AdminPage() {
  const [activeTab, setActiveTab] = useState<'overview' | 'transactions' | 'players'>('overview')

  // Simulation des données admin
  const adminStats: AdminStats = {
    totalCommissions: 2840,
    totalPlayers: 156,
    totalGames: 523,
    pendingTransactions: 8
  }

  const pendingTransactions: Transaction[] = [
    {
      id: '1',
      playerId: 'player1',
      type: 'deposit',
      amount: 500,
      status: 'pending',
      date: new Date('2024-12-06T14:30:00')
    },
    {
      id: '2',
      playerId: 'player2',
      type: 'withdrawal',
      amount: 300,
      status: 'pending',
      date: new Date('2024-12-06T13:15:00')
    },
    {
      id: '3',
      playerId: 'player3',
      type: 'deposit',
      amount: 1000,
      status: 'pending',
      date: new Date('2024-12-06T12:45:00')
    },
    {
      id: '4',
      playerId: 'player4',
      type: 'withdrawal',
      amount: 150,
      status: 'pending',
      date: new Date('2024-12-06T11:20:00')
    }
  ]

  const topPlayers: Player[] = [
    {
      id: '1',
      username: 'SpeedDemon',
      balance: 2400,
      totalWins: 45,
      totalGames: 60,
      totalEarnings: 8900,
      createdAt: new Date('2024-01-15')
    },
    {
      id: '2',
      username: 'CryptoKing',
      balance: 1800,
      totalWins: 38,
      totalGames: 55,
      totalEarnings: 7200,
      createdAt: new Date('2024-02-03')
    },
    {
      id: '3',
      username: 'RaceChampion',
      balance: 1500,
      totalWins: 42,
      totalGames: 62,
      totalEarnings: 6800,
      createdAt: new Date('2024-01-28')
    }
  ]

  const recentGames: Game[] = [
    {
      id: '1',
      player1Id: 'player1',
      player2Id: 'player2',
      player1Car: 'blue',
      player2Car: 'red',
      winnerId: 'player1',
      betAmount: 100,
      winnerEarnings: 160,
      adminCommission: 40,
      gameDate: new Date('2024-12-06T15:30:00'),
      status: 'completed'
    },
    {
      id: '2',
      player1Id: 'player3',
      player2Id: 'player4',
      player1Car: 'green',
      player2Car: 'blue',
      winnerId: 'player4',
      betAmount: 150,
      winnerEarnings: 240,
      adminCommission: 60,
      gameDate: new Date('2024-12-06T15:15:00'),
      status: 'completed'
    }
  ]

  const handleTransactionAction = (transactionId: string, action: 'approve' | 'reject') => {
    // Simulation - en vrai cela ferait appel à l'API
    console.log(`${action} transaction ${transactionId}`)
    alert(`Transaction ${transactionId} ${action === 'approve' ? 'approuvée' : 'rejetée'} (simulation)`)
  }

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date)
  }

  const getTransactionIcon = (type: Transaction['type']) => {
    switch (type) {
      case 'deposit':
        return <TrendingUp className="h-5 w-5 text-green-500" />
      case 'withdrawal':
        return <TrendingUp className="h-5 w-5 text-orange-500 rotate-180" />
      default:
        return <DollarSign className="h-5 w-5 text-gray-500" />
    }
  }

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-800 dark:text-white mb-4">
          ⚙️ Panel Administrateur
        </h1>
        <p className="text-xl text-gray-600 dark:text-gray-300">
          Gestion des transactions, joueurs et commissions
        </p>
      </div>

      {/* Statistiques générales */}
      <div className="grid md:grid-cols-4 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-300">Commissions totales</p>
              <p className="text-3xl font-bold text-green-600 dark:text-green-400" data-testid="text-total-commissions">
                {adminStats.totalCommissions} TRX
              </p>
            </div>
            <DollarSign className="h-8 w-8 text-green-500" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-300">Joueurs inscrits</p>
              <p className="text-3xl font-bold text-blue-600 dark:text-blue-400" data-testid="text-total-players">
                {adminStats.totalPlayers}
              </p>
            </div>
            <Users className="h-8 w-8 text-blue-500" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-300">Parties jouées</p>
              <p className="text-3xl font-bold text-purple-600 dark:text-purple-400" data-testid="text-total-games">
                {adminStats.totalGames}
              </p>
            </div>
            <TrendingUp className="h-8 w-8 text-purple-500" />
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-300">Transactions en attente</p>
              <p className="text-3xl font-bold text-orange-600 dark:text-orange-400" data-testid="text-pending-transactions">
                {adminStats.pendingTransactions}
              </p>
            </div>
            <Clock className="h-8 w-8 text-orange-500" />
          </div>
        </div>
      </div>

      {/* Onglets */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg">
        <div className="border-b border-gray-200 dark:border-gray-700">
          <nav className="flex space-x-8 px-6">
            {[
              { id: 'overview', label: 'Vue d\'ensemble', icon: TrendingUp },
              { id: 'transactions', label: 'Transactions', icon: DollarSign },
              { id: 'players', label: 'Joueurs', icon: Users }
            ].map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setActiveTab(id as typeof activeTab)}
                className={`flex items-center space-x-2 py-4 px-2 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === id
                    ? 'border-primary text-primary'
                    : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
                }`}
                data-testid={`tab-${id}`}
              >
                <Icon className="h-4 w-4" />
                <span>{label}</span>
              </button>
            ))}
          </nav>
        </div>

        <div className="p-6">
          {/* Vue d'ensemble */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-gray-800 dark:text-white">
                Activité récente
              </h3>
              
              <div className="grid md:grid-cols-2 gap-6">
                {/* Dernières parties */}
                <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                  <h4 className="font-semibold text-gray-800 dark:text-white mb-4">
                    Dernières parties terminées
                  </h4>
                  <div className="space-y-3">
                    {recentGames.map(game => (
                      <div key={game.id} className="flex items-center justify-between bg-white dark:bg-gray-600 p-3 rounded">
                        <div>
                          <p className="text-sm text-gray-600 dark:text-gray-300">
                            Partie {game.id} - {game.betAmount} TRX
                          </p>
                          <p className="text-xs text-gray-500 dark:text-gray-400">
                            {formatDate(game.gameDate)}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-semibold text-green-600 dark:text-green-400">
                            +{game.adminCommission} TRX
                          </p>
                          <p className="text-xs text-gray-500 dark:text-gray-400">Commission</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Top joueurs */}
                <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                  <h4 className="font-semibold text-gray-800 dark:text-white mb-4">
                    Top joueurs actifs
                  </h4>
                  <div className="space-y-3">
                    {topPlayers.map((player, index) => (
                      <div key={player.id} className="flex items-center justify-between bg-white dark:bg-gray-600 p-3 rounded">
                        <div className="flex items-center space-x-3">
                          <span className="text-lg font-bold text-gray-500 dark:text-gray-400">
                            #{index + 1}
                          </span>
                          <div>
                            <p className="font-semibold text-gray-800 dark:text-white">
                              {player.username}
                            </p>
                            <p className="text-xs text-gray-500 dark:text-gray-400">
                              {player.totalWins} victoires
                            </p>
                          </div>
                        </div>
                        <p className="text-sm font-semibold text-primary">
                          {player.balance} TRX
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Transactions */}
          {activeTab === 'transactions' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-gray-800 dark:text-white">
                Transactions en attente de validation
              </h3>
              
              <div className="space-y-4">
                {pendingTransactions.map(transaction => (
                  <div
                    key={transaction.id}
                    className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg"
                    data-testid={`transaction-${transaction.id}`}
                  >
                    <div className="flex items-center space-x-4">
                      {getTransactionIcon(transaction.type)}
                      <div>
                        <p className="font-semibold text-gray-800 dark:text-white">
                          {transaction.type === 'deposit' ? 'Dépôt' : 'Retrait'} - {transaction.amount} TRX
                        </p>
                        <p className="text-sm text-gray-600 dark:text-gray-300">
                          Joueur ID: {transaction.playerId}
                        </p>
                        <p className="text-xs text-gray-500 dark:text-gray-400">
                          {formatDate(transaction.date)}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => handleTransactionAction(transaction.id, 'approve')}
                        className="bg-green-500 hover:bg-green-600 text-white p-2 rounded-lg transition-colors"
                        data-testid={`button-approve-${transaction.id}`}
                      >
                        <Check className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => handleTransactionAction(transaction.id, 'reject')}
                        className="bg-red-500 hover:bg-red-600 text-white p-2 rounded-lg transition-colors"
                        data-testid={`button-reject-${transaction.id}`}
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {pendingTransactions.length === 0 && (
                <div className="text-center py-12">
                  <Clock className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-600 dark:text-gray-300 mb-2">
                    Aucune transaction en attente
                  </h3>
                  <p className="text-gray-500 dark:text-gray-400">
                    Toutes les transactions ont été traitées.
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Joueurs */}
          {activeTab === 'players' && (
            <div className="space-y-6">
              <h3 className="text-xl font-bold text-gray-800 dark:text-white">
                Gestion des joueurs
              </h3>
              
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 dark:bg-gray-700">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Joueur
                      </th>
                      <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Solde
                      </th>
                      <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Parties
                      </th>
                      <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Victoires
                      </th>
                      <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Gains totaux
                      </th>
                      <th className="px-6 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200 dark:divide-gray-600">
                    {topPlayers.map(player => (
                      <tr key={player.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="bg-primary text-primary-foreground w-10 h-10 rounded-full flex items-center justify-center mr-3">
                              {player.username.charAt(0).toUpperCase()}
                            </div>
                            <div>
                              <div className="text-sm font-medium text-gray-800 dark:text-white">
                                {player.username}
                              </div>
                              <div className="text-xs text-gray-500 dark:text-gray-400">
                                ID: {player.id}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-center text-primary font-semibold">
                          {player.balance} TRX
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-center text-gray-600 dark:text-gray-300">
                          {player.totalGames}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-center text-green-600 dark:text-green-400 font-semibold">
                          {player.totalWins}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-center text-yellow-600 dark:text-yellow-400 font-semibold">
                          {player.totalEarnings} TRX
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-center">
                          <button
                            className="bg-blue-500 hover:bg-blue-600 text-white px-3 py-1 rounded text-sm transition-colors"
                            data-testid={`button-view-player-${player.id}`}
                          >
                            Voir détails
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}