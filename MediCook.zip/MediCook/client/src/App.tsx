import { QueryClientProvider } from '@tanstack/react-query'
import { Router, Route, Switch } from 'wouter'
import { queryClient } from '@/lib/queryClient'
import HomePage from '@/pages/HomePage'
import GamePage from '@/pages/GamePage'
import ProfilePage from '@/pages/ProfilePage'
import LeaderboardPage from '@/pages/LeaderboardPage'
import HistoryPage from '@/pages/HistoryPage'
import AdminPage from '@/pages/AdminPage'
import Navbar from '@/components/Navbar'

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-blue-900">
          <Navbar />
          <main className="container mx-auto px-4 py-8">
            <Switch>
              <Route path="/" component={HomePage} />
              <Route path="/game" component={GamePage} />
              <Route path="/profile" component={ProfilePage} />
              <Route path="/leaderboard" component={LeaderboardPage} />
              <Route path="/history" component={HistoryPage} />
              <Route path="/admin" component={AdminPage} />
              <Route>
                <div className="text-center py-20">
                  <h1 className="text-4xl font-bold text-gray-800 dark:text-white mb-4">
                    404 - Page non trouvée
                  </h1>
                  <p className="text-gray-600 dark:text-gray-300">
                    La page que vous recherchez n'existe pas.
                  </p>
                </div>
              </Route>
            </Switch>
          </main>
        </div>
      </Router>
    </QueryClientProvider>
  )
}

export default App