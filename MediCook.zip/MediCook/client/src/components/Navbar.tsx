import { Link, useLocation } from 'wouter'
import { Car, Trophy, History, User, Settings, Home } from 'lucide-react'

export default function Navbar() {
  const [location] = useLocation()

  const navItems = [
    { path: '/', label: 'Accueil', icon: Home },
    { path: '/game', label: 'Jouer', icon: Car },
    { path: '/leaderboard', label: 'Classement', icon: Trophy },
    { path: '/history', label: 'Historique', icon: History },
    { path: '/profile', label: 'Profil', icon: User },
    { path: '/admin', label: 'Admin', icon: Settings },
  ]

  return (
    <nav className="bg-white dark:bg-gray-800 shadow-lg border-b border-gray-200 dark:border-gray-700">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center space-x-2">
            <Car className="h-8 w-8 text-primary" />
            <span className="text-xl font-bold text-gray-800 dark:text-white">
              TRX Racing
            </span>
          </Link>
          
          <div className="hidden md:flex items-center space-x-1">
            {navItems.map(({ path, label, icon: Icon }) => (
              <Link
                key={path}
                href={path}
                className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                  location === path
                    ? 'bg-primary text-primary-foreground'
                    : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                }`}
                data-testid={`nav-link-${path.slice(1) || 'home'}`}
              >
                <Icon className="h-4 w-4" />
                <span>{label}</span>
              </Link>
            ))}
          </div>
          
          {/* Mobile menu */}
          <div className="md:hidden flex items-center space-x-1">
            {navItems.slice(0, 4).map(({ path, label, icon: Icon }) => (
              <Link
                key={path}
                href={path}
                className={`p-2 rounded-md transition-colors ${
                  location === path
                    ? 'bg-primary text-primary-foreground'
                    : 'text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700'
                }`}
                data-testid={`mobile-nav-${path.slice(1) || 'home'}`}
              >
                <Icon className="h-5 w-5" />
              </Link>
            ))}
          </div>
        </div>
      </div>
    </nav>
  )
}