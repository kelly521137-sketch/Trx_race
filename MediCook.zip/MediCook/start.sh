#!/bin/bash
echo "🚀 Démarrage du serveur TRX Racing..."
tsx server/index.ts